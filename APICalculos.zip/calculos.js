module.exports = {
    area: function(width) {
    return Math.pow(width, 2);
    },
    perimetro: function (width){
    return width * 4;
    }
   };